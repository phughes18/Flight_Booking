
#ifndef HOPPER_H
#define HOPPER_H
#include "aircraft.h"

#include <iostream>

using namespace std;

class Hopper : public Aircraft
{
	public:
		Hopper();

	private:
};

#endif