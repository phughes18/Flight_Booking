#include <iostream>
#include <fstream>
#include "jumbo.h"

using namespace std;


Jumbo::Jumbo()
{
	total_seats = 180;
	seats_per_row = 9;
	rows = 20;
	first_rows = 6;
	econ_rows = 14;
}





