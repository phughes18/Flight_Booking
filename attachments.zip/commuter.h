
#ifndef COMMUTER_H
#define COMMUTER_H
#include "aircraft.h"

using namespace std;

class Commuter : public Aircraft
{
	public:
		Commuter();

	private:

};

#endif