
#ifndef JUMBO_H
#define JUMBO_H
#include "aircraft.h"
#include <fstream>
#include <iostream>

using namespace std;

class Jumbo : public Aircraft
{
	public:
		Jumbo();


	private:
};

#endif
