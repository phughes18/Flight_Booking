
#include <iostream>
#include "hopper.h"

using namespace std;

Hopper::Hopper()
{
	total_seats = 30;
	seats_per_row = 3;
	first_rows = 3;
	econ_rows = 7;
	rows = 10;
}

